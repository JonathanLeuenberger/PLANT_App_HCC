# PLANT_App_HCC

Android class project. This branch adds Isaiah's plant search contribution: local and online plant search, thumbnail results and a read-only plant information screen.

Open the repository folder in Android Studio and run **app** on an Android emulator or phone (Android 7.0/API 24 or newer). Search is the entry screen for testing this contribution. The rest of the team's app features are outside this branch.

See [the search feature guide](docs/SEARCH_FEATURE.md) for the code structure, demonstration steps, team integration and tests, and [content credits](docs/SEARCH_THIRD_PARTY.md) for Wikipedia and Wikimedia attribution.
